import streamlit as st
import pandas as pd
import numpy as np

st.header("My Projects")


project_name = "Gety World"
project_type = " E-coomerc"
product_image = "https://placekitten.com/200/300"

card(
    title = project_name,
    Text = project_type,
    image = product_image,

)